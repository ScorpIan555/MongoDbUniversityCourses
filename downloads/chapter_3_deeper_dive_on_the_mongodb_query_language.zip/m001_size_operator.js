db.movieDetails.find({countries: {$size: 1}}).pretty()
